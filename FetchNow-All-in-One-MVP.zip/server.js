require("dotenv").config();
const express=require("express"), Database=require("better-sqlite3"), path=require("path");
const app=express(), db=new Database("fetchnow.db");
app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));
db.exec(`
CREATE TABLE IF NOT EXISTS orders(
 id TEXT PRIMARY KEY,name TEXT,phone TEXT,pickup TEXT,dropoff TEXT,item TEXT,speed TEXT,
 distance_km REAL,fare INTEGER,status TEXT,partner_id INTEGER,payment_status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS partners(
 id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,vehicle TEXT,status TEXT,created_at TEXT);
`);
const rates={standard:12,fast:16,urgent:22};
const statuses=["requested","accepted","picked_up","on_the_way","delivered","cancelled"];
const id=()=> "FN"+Math.floor(10000+Math.random()*90000);

app.get("/api/health",(q,s)=>s.json({ok:true,service:"FetchNow"}));
app.get("/api/orders",(q,s)=>s.json(db.prepare("SELECT * FROM orders ORDER BY created_at DESC").all()));
app.get("/api/partners",(q,s)=>s.json(db.prepare("SELECT * FROM partners ORDER BY id DESC").all()));

app.post("/api/orders",(q,s)=>{
 const b=q.body;if(!b.name||!b.phone||!b.pickup||!b.dropoff||!b.item)return s.status(400).json({error:"Missing required fields"});
 const km=Math.max(1,Number(b.distance_km)||1),speed=b.speed||"standard",fare=Math.round(35+km*(rates[speed]||12)),oid=id();
 db.prepare("INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)").run(oid,b.name,b.phone,b.pickup,b.dropoff,b.item,speed,km,fare,"requested",null,"unpaid",new Date().toISOString());
 s.status(201).json({id:oid,fare,status:"requested",payment_status:"unpaid"});
});
app.post("/api/partners",(q,s)=>{
 const b=q.body;if(!b.name||!b.phone||!b.vehicle)return s.status(400).json({error:"Missing fields"});
 const r=db.prepare("INSERT INTO partners(name,phone,vehicle,status,created_at) VALUES(?,?,?,?,?)").run(b.name,b.phone,b.vehicle,"online",new Date().toISOString());
 s.status(201).json({id:r.lastInsertRowid,status:"online"});
});
app.post("/api/orders/:id/accept",(q,s)=>{
 const p=q.body.partner_id;if(!p)return s.status(400).json({error:"partner_id required"});
 const partner=db.prepare("SELECT * FROM partners WHERE id=?").get(p);if(!partner)return s.status(404).json({error:"Partner not found"});
 const r=db.prepare("UPDATE orders SET partner_id=?,status='accepted' WHERE id=? AND status='requested'").run(p,q.params.id);
 if(!r.changes)return s.status(409).json({error:"Order unavailable"});
 s.json({id:q.params.id,status:"accepted",partner});
});
app.patch("/api/orders/:id/status",(q,s)=>{
 if(!statuses.includes(q.body.status))return s.status(400).json({error:"Invalid status"});
 const r=db.prepare("UPDATE orders SET status=? WHERE id=?").run(q.body.status,q.params.id);
 if(!r.changes)return s.status(404).json({error:"Order not found"});s.json({id:q.params.id,status:q.body.status});
});
app.post("/api/orders/:id/pay",(q,s)=>{
 const r=db.prepare("UPDATE orders SET payment_status='paid' WHERE id=?").run(q.params.id);
 if(!r.changes)return s.status(404).json({error:"Order not found"});
 s.json({id:q.params.id,payment_status:"paid",note:"Demo payment recorded. Replace this endpoint with a real payment provider checkout."});
});
app.get("/api/orders/:id",(q,s)=>{const o=db.prepare("SELECT * FROM orders WHERE id=?").get(q.params.id);o?s.json(o):s.status(404).json({error:"Order not found"})});
app.get("*",(q,s)=>s.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("FetchNow running on http://localhost:"+(process.env.PORT||3000)));
