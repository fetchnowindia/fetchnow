require('dotenv').config();
const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const crypto = require('crypto');

const app = express();
const db = new Database(process.env.DB_PATH || 'fetchnow.db');
const PORT = Number(process.env.PORT || 3000);
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'vaidyashantanu75@gmail.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const FRONTEND_URL = process.env.FRONTEND_URL || '';
const sessions = new Map();

app.use(express.json({limit:'200kb'}));
app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');next()});
app.use((req,res,next)=>{
  const origin=req.headers.origin;
  if(origin && FRONTEND_URL && origin===FRONTEND_URL){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Access-Control-Allow-Credentials','true');res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization');res.setHeader('Access-Control-Allow-Methods','GET,POST,PATCH,OPTIONS');}
  if(req.method==='OPTIONS') return res.sendStatus(204); next();
});
app.use(express.static(path.join(__dirname,'public')));

db.exec(`
CREATE TABLE IF NOT EXISTS orders(
 id TEXT PRIMARY KEY,name TEXT,phone TEXT,pickup TEXT,dropoff TEXT,item TEXT,speed TEXT,
 distance_km REAL,fare INTEGER,status TEXT,partner_id INTEGER,payment_status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS partners(
 id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,vehicle TEXT,status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS partner_applications(
 id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,email TEXT,vehicle TEXT,
 licence_number TEXT,licence_expiry TEXT,email_verified INTEGER DEFAULT 0,status TEXT DEFAULT 'pending',
 verification_token_hash TEXT,verification_expires_at TEXT,created_at TEXT,verified_at TEXT);
`);

const rates={standard:12,fast:16,urgent:22};
const statuses=['requested','accepted','picked_up','on_the_way','delivered','cancelled'];
const id=()=>`FN${Math.floor(10000+Math.random()*90000)}`;
const sha256=v=>crypto.createHash('sha256').update(v).digest('hex');
const escapeHtml=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

async function sendEmail({to,subject,html}){
  if(!process.env.RESEND_API_KEY) return {sent:false,reason:'email_not_configured'};
  const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.EMAIL_FROM||'FetchNow <onboarding@resend.dev>',to,subject,html})});
  if(!r.ok) throw new Error(await r.text());
  return {sent:true};
}

function requireAdmin(req,res,next){
  const auth=req.headers.authorization||''; const token=auth.startsWith('Bearer ')?auth.slice(7):'';
  const session=sessions.get(token);
  if(!session || session.expiresAt<Date.now()){if(token)sessions.delete(token);return res.status(401).json({error:'Admin login required.'});}
  next();
}

app.get('/api/health',(q,s)=>s.json({ok:true,service:'FetchNow'}));
app.post('/api/admin/login',(req,res)=>{
  if(!ADMIN_PASSWORD) return res.status(503).json({error:'Admin password is not configured on the server.'});
  const password=String(req.body?.password||'');
  if(password.length<1 || password!==ADMIN_PASSWORD) return res.status(401).json({error:'Invalid admin password.'});
  const token=crypto.randomBytes(32).toString('hex');
  sessions.set(token,{expiresAt:Date.now()+8*60*60*1000});
  res.json({ok:true,token,expires_in:8*60*60});
});
app.post('/api/admin/logout',requireAdmin,(req,res)=>{const a=req.headers.authorization||'';sessions.delete(a.slice(7));res.json({ok:true})});

app.get('/api/orders',(q,s)=>s.json(db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all()));
app.get('/api/orders/:id',(q,s)=>{const o=db.prepare('SELECT * FROM orders WHERE id=?').get(q.params.id);o?s.json(o):s.status(404).json({error:'Order not found'})});
app.post('/api/orders',(q,s)=>{
 const b=q.body;if(!b.name||!b.phone||!b.pickup||!b.dropoff||!b.item)return s.status(400).json({error:'Missing required fields'});
 const km=Math.max(1,Number(b.distance_km)||1),speed=b.speed||'standard',fare=Math.round(35+km*(rates[speed]||12)),oid=id();
 db.prepare('INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').run(oid,String(b.name).trim(),String(b.phone).trim(),String(b.pickup).trim(),String(b.dropoff).trim(),String(b.item).trim(),speed,km,fare,'requested',null,'unpaid',new Date().toISOString());
 s.status(201).json({id:oid,fare,status:'requested',payment_status:'unpaid'});
});
app.post('/api/orders/:id/pay',(q,s)=>{const r=db.prepare("UPDATE orders SET payment_status='paid' WHERE id=?").run(q.params.id);if(!r.changes)return s.status(404).json({error:'Order not found'});s.json({id:q.params.id,payment_status:'paid'})});
app.patch('/api/orders/:id/status',requireAdmin,(q,s)=>{if(!statuses.includes(q.body.status))return s.status(400).json({error:'Invalid status'});const r=db.prepare('UPDATE orders SET status=? WHERE id=?').run(q.body.status,q.params.id);if(!r.changes)return s.status(404).json({error:'Order not found'});s.json({id:q.params.id,status:q.body.status})});
app.post('/api/orders/:id/accept',requireAdmin,(q,s)=>{const p=q.body.partner_id;if(!p)return s.status(400).json({error:'partner_id required'});const partner=db.prepare('SELECT * FROM partners WHERE id=?').get(p);if(!partner)return s.status(404).json({error:'Partner not found'});const r=db.prepare("UPDATE orders SET partner_id=?,status='accepted' WHERE id=? AND status='requested'").run(p,q.params.id);if(!r.changes)return s.status(409).json({error:'Order unavailable'});s.json({id:q.params.id,status:'accepted',partner})});

app.post('/api/partners/apply',async(req,res)=>{
 const b=req.body||{};
 if(!b.name||!b.phone||!b.email||!b.vehicle||!b.licence_number||!b.licence_expiry)return res.status(400).json({error:'Name, phone, email, vehicle, licence number and licence expiry are required.'});
 const email=String(b.email).trim().toLowerCase();
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return res.status(400).json({error:'Enter a valid email address.'});
 const expiry=new Date(`${b.licence_expiry}T23:59:59`);if(Number.isNaN(expiry.getTime()))return res.status(400).json({error:'Enter a valid licence expiry date.'});
 if(expiry.getTime()<Date.now())return res.status(400).json({error:'Driving licence is expired. Please enter a valid licence.'});
 const existing=db.prepare("SELECT id FROM partner_applications WHERE email=? AND status IN ('pending','verified','approved')").get(email);if(existing)return res.status(409).json({error:'An application with this email already exists.'});
 const token=crypto.randomBytes(32).toString('hex');const hash=sha256(token);const expires=new Date(Date.now()+30*60*1000).toISOString();
 const r=db.prepare(`INSERT INTO partner_applications(name,phone,email,vehicle,licence_number,licence_expiry,email_verified,status,verification_token_hash,verification_expires_at,created_at) VALUES(?,?,?,?,?,?,0,'pending',?,?,?)`).run(String(b.name).trim(),String(b.phone).trim(),email,String(b.vehicle),String(b.licence_number).trim(),b.licence_expiry,hash,expires,new Date().toISOString());
 const base=process.env.PUBLIC_URL||`http://localhost:${PORT}`;const link=`${base}/verify-email.html?token=${token}`;
 try{await sendEmail({to:email,subject:'Verify your FetchNow partner email',html:`<div style="font-family:Arial"><h2>FetchNow Partner Verification</h2><p>Hello ${escapeHtml(b.name)},</p><p>Verify your email within 30 minutes:</p><p><a href="${link}" style="display:inline-block;padding:12px 18px;background:#ffbf00;color:#111;text-decoration:none;border-radius:8px;font-weight:bold">Verify Email</a></p></div>`});}
 catch(err){db.prepare('DELETE FROM partner_applications WHERE id=?').run(r.lastInsertRowid);console.error(err);return res.status(502).json({error:'Could not send verification email. Please try again later.'});}
 res.status(201).json({id:r.lastInsertRowid,message:'Verification email sent. Verify your email before admin review.'});
});

app.get('/api/partners/verify',async(req,res)=>{
 const token=String(req.query.token||'');if(!token)return res.status(400).json({error:'Verification token is missing.'});
 const row=db.prepare('SELECT * FROM partner_applications WHERE verification_token_hash=?').get(sha256(token));if(!row)return res.status(400).json({error:'Invalid or already used verification link.'});
 if(new Date(row.verification_expires_at).getTime()<Date.now())return res.status(410).json({error:'Verification link has expired. Please submit the form again.'});
 db.prepare("UPDATE partner_applications SET email_verified=1,status='verified',verification_token_hash=NULL,verification_expires_at=NULL,verified_at=? WHERE id=?").run(new Date().toISOString(),row.id);
 try{await sendEmail({to:ADMIN_EMAIL,subject:`New FetchNow partner application #${row.id}`,html:`<div style="font-family:Arial"><h2>New Partner Application</h2><p><b>Name:</b> ${escapeHtml(row.name)}</p><p><b>Phone:</b> ${escapeHtml(row.phone)}</p><p><b>Email:</b> ${escapeHtml(row.email)}</p><p><b>Vehicle:</b> ${escapeHtml(row.vehicle)}</p><p><b>Licence:</b> ${escapeHtml(row.licence_number)}</p><p><b>Licence expiry:</b> ${escapeHtml(row.licence_expiry)}</p><p>Email verified. Please review it in the Admin dashboard.</p></div>`});}catch(err){console.error(err)}
 res.json({ok:true,message:'Email verified successfully. Your application is now waiting for admin review.'});
});

app.get('/api/partners',requireAdmin,(q,s)=>s.json(db.prepare('SELECT * FROM partners ORDER BY id DESC').all()));
app.get('/api/partner-applications',requireAdmin,(q,s)=>s.json(db.prepare('SELECT id,name,phone,email,vehicle,licence_number,licence_expiry,email_verified,status,created_at,verified_at FROM partner_applications ORDER BY id DESC').all()));
app.post('/api/partner-applications/:id/approve',requireAdmin,(q,s)=>{const row=db.prepare('SELECT * FROM partner_applications WHERE id=?').get(q.params.id);if(!row)return s.status(404).json({error:'Application not found'});if(!row.email_verified)return s.status(400).json({error:'Email must be verified before approval.'});if(row.status==='approved')return s.json({ok:true,status:'approved'});const r=db.prepare('INSERT INTO partners(name,phone,vehicle,status,created_at) VALUES(?,?,?,?,?)').run(row.name,row.phone,row.vehicle,'online',new Date().toISOString());db.prepare("UPDATE partner_applications SET status='approved' WHERE id=?").run(row.id);s.json({ok:true,status:'approved',partner_id:r.lastInsertRowid})});
app.post('/api/partner-applications/:id/reject',requireAdmin,(q,s)=>{const r=db.prepare("UPDATE partner_applications SET status='rejected' WHERE id=?").run(q.params.id);if(!r.changes)return s.status(404).json({error:'Application not found'});s.json({ok:true,status:'rejected'})});

app.get('*',(q,s)=>s.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`FetchNow running on http://localhost:${PORT}`));
