// If FetchNow frontend is hosted on GitHub Pages, set this to your backend URL.
// Example: window.FETCHNOW_API_BASE = 'https://fetchnow-api.example.com';
window.FETCHNOW_API_BASE = '';
